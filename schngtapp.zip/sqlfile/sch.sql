SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Create table 'students'
CREATE TABLE students (
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(100) NOT NULL,
    username VARCHAR(100) NOT NULL,
    courses VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL
);



