

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="veiwport" content="width=device-width, initial-scale=1.0" />
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="css/style.css"/>
    </head>
    <body>
        <header>
        <?php include 'includes/header.php'; ?>
        </header>
        <br/><br/>
        <div id="intro">
            <button><a href="http://localhost/PROJECTS/SchMgtApp/login.php">Login</a></button><br/><br/>
            <button><a href="http://localhost/PROJECTS/SchMgtApp/register.php">Register</a></button>
        </div>
        <footer>
            <div>
            <?php include 'includes/footer.php'; ?>
            </div>
        </footer>
    </body>
</html>