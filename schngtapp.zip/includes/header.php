<?php
echo '<a href="http://localhost/PROJECTS/SchMgtApp/index.php">
      <h1>School Management Portal</h1></a>';
?>