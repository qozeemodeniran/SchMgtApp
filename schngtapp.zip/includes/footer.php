<?php
echo "<p>&copy; schoolmanagementportal.com 1994 - ".date("Y")."</p>";
?>