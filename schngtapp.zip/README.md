# SchMgtApp
This a school management app.
